// Tripora frontend - talks to the Node.js/Express API and MongoDB.
let currentTrip = null;

const places = {
  goa: ["Visit Baga Beach and enjoy water sports", "Explore Fort Aguada and Candolim Beach", "Discover Old Goa churches and local markets", "Enjoy a sunset at Anjuna Beach"],
  manali: ["Explore Solang Valley", "Visit Hadimba Devi Temple", "Enjoy the beauty of Old Manali", "Explore Atal Tunnel and nearby attractions"],
  ooty: ["Visit Ooty Botanical Garden", "Enjoy a ride on the Nilgiri Mountain Railway", "Explore Ooty Lake", "Visit Doddabetta Peak"],
  jaipur: ["Explore Amber Fort", "Visit Hawa Mahal", "Discover City Palace", "Explore local markets"],
  mumbai: ["Visit Gateway of India", "Explore Marine Drive", "Visit Elephanta Caves", "Discover Juhu Beach"]
};

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong");
  return data;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function generateTrip() {
  const destination = document.getElementById("destination").value.trim();
  const days = Number(document.getElementById("days").value);
  const budget = Number(document.getElementById("budget").value);
  const result = document.getElementById("trip-result");

  if (!destination || !Number.isInteger(days) || days < 1 || !Number.isFinite(budget) || budget <= 0) {
    result.innerHTML = "<p style='color:red;'>Please enter a valid destination, number of days and budget.</p>";
    return;
  }

  const hotel = budget * 0.40;
  const food = budget * 0.25;
  const transport = budget * 0.20;
  const activities = budget * 0.15;
  const selectedPlaces = places[destination.toLowerCase()] || [
    "Explore popular tourist attractions", "Discover local food and restaurants",
    "Visit famous landmarks", "Enjoy local shopping and sightseeing"
  ];
  const itinerary = Array.from({ length: days }, (_, i) => selectedPlaces[i % selectedPlaces.length]);

  currentTrip = { destination, days, budget, hotel, food, transport, activities, itinerary };

  result.innerHTML = `
    <div style="background:#f1f5f9;padding:20px;border-radius:12px;">
      <h3 style="color:#152b45;">Your ${escapeHTML(destination)} Trip ✈</h3>
      <p><strong>Duration:</strong> ${days} Days</p>
      <p><strong>Total Budget:</strong> ₹${budget.toLocaleString("en-IN")}</p>
      <hr>
      <h4>Estimated Budget Breakdown</h4>
      <p>🏨 Hotel: ₹${hotel.toFixed(2)}</p>
      <p>🍽 Food: ₹${food.toFixed(2)}</p>
      <p>🚗 Transport: ₹${transport.toFixed(2)}</p>
      <p>🎯 Activities: ₹${activities.toFixed(2)}</p>
      <hr>
      <h4>Your Travel Itinerary</h4>
      ${itinerary.map((activity, i) => `<p style="margin:12px 0;"><strong>Day ${i + 1}:</strong> ${escapeHTML(activity)}</p>`).join("")}
      <button onclick="saveTrip()" style="margin-top:15px;">Save This Trip</button>
    </div>`;
}

async function saveTrip() {
  if (!currentTrip) {
    alert("Please generate a trip first!");
    return;
  }
  try {
    await apiRequest("/api/trips", {
      method: "POST",
      body: JSON.stringify(currentTrip)
    });
    alert("Your trip has been saved to MongoDB!");
    await displayTrips();
  } catch (error) {
    alert(error.message);
  }
}

async function displayTrips() {
  const savedTrips = document.getElementById("saved-trips");
  try {
    const trips = await apiRequest("/api/trips");
    if (!trips.length) {
      savedTrips.innerHTML = "<p>No trips saved yet. Start planning your adventure!</p>";
      updateDashboard(trips);
      return;
    }

    savedTrips.innerHTML = trips.map(trip => `
      <div style="background:white;padding:20px;margin:15px auto;max-width:500px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.08);text-align:left;">
        <h3>✈ ${escapeHTML(trip.destination)}</h3>
        <p>Duration: ${trip.days} Days</p>
        <p>Budget: ₹${Number(trip.budget).toLocaleString("en-IN")}</p>
        <p>Created: ${new Date(trip.createdAt).toLocaleDateString("en-IN")}</p>
        <button onclick="deleteTrip('${trip._id}')" style="background:#e74c3c;color:white;border:none;padding:9px 15px;border-radius:6px;cursor:pointer;margin-top:10px;">Delete Trip</button>
      </div>`).join("");
    updateDashboard(trips);
  } catch (error) {
    savedTrips.innerHTML = `<p style="color:red;">${escapeHTML(error.message)}. Check that the server and MongoDB are running.</p>`;
  }
}

async function deleteTrip(id) {
  if (!confirm("Are you sure you want to delete this trip?")) return;
  try {
    await apiRequest(`/api/trips/${encodeURIComponent(id)}`, { method: "DELETE" });
    await displayTrips();
  } catch (error) {
    alert(error.message);
  }
}

function updateDashboard(trips = []) {
  const totalBudget = trips.reduce((sum, trip) => sum + Number(trip.budget), 0);
  const destinations = new Set(trips.map(trip => trip.destination.toLowerCase()));
  document.getElementById("total-trips").textContent = trips.length;
  document.getElementById("total-budget").textContent = `₹${totalBudget.toLocaleString("en-IN")}`;
  document.getElementById("total-destinations").textContent = destinations.size;
}

document.addEventListener("DOMContentLoaded", displayTrips);
