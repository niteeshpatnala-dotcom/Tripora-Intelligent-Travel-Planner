const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema({
  destination: { type: String, required: true, trim: true },
  days: { type: Number, required: true, min: 1 },
  budget: { type: Number, required: true, min: 1 },
  hotel: { type: Number, required: true },
  food: { type: Number, required: true },
  transport: { type: Number, required: true },
  activities: { type: Number, required: true },
  itinerary: [{ type: String }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Trip", tripSchema);
