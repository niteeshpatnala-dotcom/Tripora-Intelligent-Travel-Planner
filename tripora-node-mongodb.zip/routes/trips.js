const express = require("express");
const Trip = require("../models/Trip");
const router = express.Router();

// Get all saved trips
router.get("/", async (req, res) => {
  try {
    const trips = await Trip.find().sort({ createdAt: -1 });
    res.json(trips);
  } catch (error) {
    res.status(500).json({ message: "Could not fetch trips" });
  }
});

// Save a trip
router.post("/", async (req, res) => {
  try {
    const { destination, days, budget, hotel, food, transport, activities, itinerary } = req.body;
    if (!destination || !Number.isInteger(Number(days)) || Number(days) < 1 ||
        !Number.isFinite(Number(budget)) || Number(budget) <= 0) {
      return res.status(400).json({ message: "Enter a valid destination, number of days and budget." });
    }

    const trip = await Trip.create({
      destination: String(destination).trim(),
      days: Number(days),
      budget: Number(budget),
      hotel: Number(hotel),
      food: Number(food),
      transport: Number(transport),
      activities: Number(activities),
      itinerary: Array.isArray(itinerary) ? itinerary : []
    });
    res.status(201).json(trip);
  } catch (error) {
    res.status(500).json({ message: "Could not save trip" });
  }
});

// Delete a saved trip by MongoDB ID
router.delete("/:id", async (req, res) => {
  try {
    const trip = await Trip.findByIdAndDelete(req.params.id);
    if (!trip) return res.status(404).json({ message: "Trip not found" });
    res.json({ message: "Trip deleted successfully" });
  } catch (error) {
    res.status(400).json({ message: "Invalid trip ID" });
  }
});

module.exports = router;
