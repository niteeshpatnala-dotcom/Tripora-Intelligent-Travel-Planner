# Tripora - Node.js + MongoDB

## Requirements
- Node.js (LTS)
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- VS Code

## Setup
1. Open this folder in VS Code.
2. Open Terminal > New Terminal.
3. Run `npm install`.
4. Copy `.env.example` to a new file named `.env`.
5. In `.env`, set `MONGODB_URI`:
   - Local MongoDB: `mongodb://127.0.0.1:27017/tripora`
   - MongoDB Atlas: paste your Atlas connection string (replace its username/password placeholders). Do not share or commit `.env`.
6. Make sure your MongoDB service is running.
7. Run `npm run dev` (or `npm start`).
8. Open `http://localhost:3000` in your browser.

## API
- `GET /api/health` - check server
- `GET /api/trips` - list saved trips
- `POST /api/trips` - save a trip
- `DELETE /api/trips/:id` - delete a trip

Saved trips are stored in MongoDB collection `trips` in database `tripora`.
